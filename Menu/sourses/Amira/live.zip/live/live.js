const labels = document.querySelectorAll('.form-control label');
labels.forEach(function (label) {
    label.innerHTML = label.innerText.split("").map(function (letter, idx) {
        return `<span style="transition-delay:${idx * 50}ms;">${letter}</span>`
    }).join("");
});

button = document.getElementById("submitData");

button.addEventListener("click", () => {
    if (confirm("Do you want to subscribe?")) {
        // alert('you have been subscribed');
        location.href = '../Home/home.html';
    }
    else {
        location.href = 'live.html';
    }
});
